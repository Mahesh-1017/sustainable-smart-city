import streamlit as st

def summary_card(title: str, value: str):
    st.markdown(f"### {title}")

